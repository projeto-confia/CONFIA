--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 13.1 (Debian 13.1-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY detectenv.user_role DROP CONSTRAINT user_account_user_role_fk;
ALTER TABLE ONLY detectenv.checking_outcome DROP CONSTRAINT trusted_agency_checking_outcome_fk;
ALTER TABLE ONLY detectenv.social_media_account DROP CONSTRAINT social_media_social_media_account_fk;
ALTER TABLE ONLY detectenv.post DROP CONSTRAINT social_media_account_post_fk;
ALTER TABLE ONLY detectenv.user_role DROP CONSTRAINT role_user_role_fk;
ALTER TABLE ONLY detectenv.permission DROP CONSTRAINT role_permission_fk;
ALTER TABLE ONLY detectenv.post DROP CONSTRAINT post_post_fk;
ALTER TABLE ONLY detectenv.permission DROP CONSTRAINT permission_type_permission_fk;
ALTER TABLE ONLY detectenv.social_media_account DROP CONSTRAINT owner_social_media_account_fk;
ALTER TABLE ONLY detectenv.post DROP CONSTRAINT news_post_fk;
ALTER TABLE ONLY detectenv.checking_outcome DROP CONSTRAINT news_checking_outcome_fk;
ALTER TABLE ONLY detectenv.action_log DROP CONSTRAINT news_action_log_fk;
ALTER TABLE ONLY detectenv.action_log DROP CONSTRAINT action_type_action_log_fk;
DROP INDEX detectenv.name_user_account_idx;
DROP INDEX detectenv.name_trusted_agency_idx;
DROP INDEX detectenv.name_social_media_idx;
DROP INDEX detectenv.name_role_idx;
DROP INDEX detectenv.name_permission_type_idx;
DROP INDEX detectenv.name_owner_idx;
DROP INDEX detectenv.name_action_type_idx;
DROP INDEX detectenv.id_user_id_role_user_role_idx;
DROP INDEX detectenv.id_social_id_owner_social_media_account_idx;
DROP INDEX detectenv.id_permission_id_role_permission_idx;
ALTER TABLE ONLY detectenv.user_role DROP CONSTRAINT user_role_pkey;
ALTER TABLE ONLY detectenv.user_account DROP CONSTRAINT user_account_pkey;
ALTER TABLE ONLY detectenv.trusted_agency DROP CONSTRAINT trusted_agency_pkey;
ALTER TABLE ONLY detectenv.social_media DROP CONSTRAINT social_media_pkey;
ALTER TABLE ONLY detectenv.social_media_account DROP CONSTRAINT social_media_account_pkey;
ALTER TABLE ONLY detectenv.role DROP CONSTRAINT role_pkey;
ALTER TABLE ONLY detectenv.post DROP CONSTRAINT post_pkey;
ALTER TABLE ONLY detectenv.permission_type DROP CONSTRAINT permission_type_pkey;
ALTER TABLE ONLY detectenv.permission DROP CONSTRAINT permission_pkey;
ALTER TABLE ONLY detectenv.owner DROP CONSTRAINT owner_pkey;
ALTER TABLE ONLY detectenv.news DROP CONSTRAINT news_pkey;
ALTER TABLE ONLY detectenv.checking_outcome DROP CONSTRAINT checking_outcome_pkey;
ALTER TABLE ONLY detectenv.action_type DROP CONSTRAINT action_type_pkey;
ALTER TABLE ONLY detectenv.action_log DROP CONSTRAINT action_log_pkey;
ALTER TABLE detectenv.user_role ALTER COLUMN id_user_role DROP DEFAULT;
ALTER TABLE detectenv.user_account ALTER COLUMN id_user_account DROP DEFAULT;
ALTER TABLE detectenv.trusted_agency ALTER COLUMN id_trusted_agency DROP DEFAULT;
ALTER TABLE detectenv.social_media_account ALTER COLUMN id_social_media_account DROP DEFAULT;
ALTER TABLE detectenv.social_media ALTER COLUMN id_social_media DROP DEFAULT;
ALTER TABLE detectenv.role ALTER COLUMN id_role DROP DEFAULT;
ALTER TABLE detectenv.post ALTER COLUMN id_post DROP DEFAULT;
ALTER TABLE detectenv.permission_type ALTER COLUMN id_permission_type DROP DEFAULT;
ALTER TABLE detectenv.permission ALTER COLUMN id_permission DROP DEFAULT;
ALTER TABLE detectenv.owner ALTER COLUMN id_owner DROP DEFAULT;
ALTER TABLE detectenv.news ALTER COLUMN id_news DROP DEFAULT;
ALTER TABLE detectenv.checking_outcome ALTER COLUMN id_checking_outcome DROP DEFAULT;
ALTER TABLE detectenv.action_type ALTER COLUMN id_action DROP DEFAULT;
ALTER TABLE detectenv.action_log ALTER COLUMN id_action_log DROP DEFAULT;
DROP SEQUENCE detectenv.user_role_id_user_role_seq;
DROP TABLE detectenv.user_role;
DROP SEQUENCE detectenv.user_account_id_user_account_seq;
DROP TABLE detectenv.user_account;
DROP SEQUENCE detectenv.trusted_agency_id_trusted_agency_seq;
DROP TABLE detectenv.trusted_agency;
DROP SEQUENCE detectenv.social_media_id_social_media_seq;
DROP SEQUENCE detectenv.social_media_account_id_social_media_account_seq;
DROP TABLE detectenv.social_media_account;
DROP TABLE detectenv.social_media;
DROP SEQUENCE detectenv.role_id_role_seq;
DROP TABLE detectenv.role;
DROP SEQUENCE detectenv.post_id_post_seq;
DROP TABLE detectenv.post;
DROP SEQUENCE detectenv.permission_type_id_permission_type_seq;
DROP TABLE detectenv.permission_type;
DROP SEQUENCE detectenv.permission_id_permission_seq;
DROP TABLE detectenv.permission;
DROP SEQUENCE detectenv.owner_id_owner_seq;
DROP TABLE detectenv.owner;
DROP SEQUENCE detectenv.news_id_news_seq;
DROP TABLE detectenv.news;
DROP SEQUENCE detectenv.checking_outcome_id_checking_outcome_seq;
DROP TABLE detectenv.checking_outcome;
DROP SEQUENCE detectenv.action_type_id_action_seq;
DROP TABLE detectenv.action_type;
DROP SEQUENCE detectenv.action_log_id_action_log_seq;
DROP TABLE detectenv.action_log;
DROP SCHEMA detectenv;
--
-- Name: detectenv; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA detectenv;


ALTER SCHEMA detectenv OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action_log; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.action_log (
    id_action_log integer NOT NULL,
    id_action integer NOT NULL,
    id_news integer NOT NULL,
    datetime_log timestamp without time zone NOT NULL,
    description_log character varying(100) NOT NULL
);


ALTER TABLE detectenv.action_log OWNER TO admin;

--
-- Name: action_log_id_action_log_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.action_log_id_action_log_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.action_log_id_action_log_seq OWNER TO admin;

--
-- Name: action_log_id_action_log_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.action_log_id_action_log_seq OWNED BY detectenv.action_log.id_action_log;


--
-- Name: action_type; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.action_type (
    id_action integer NOT NULL,
    name_action character varying(20) NOT NULL
);


ALTER TABLE detectenv.action_type OWNER TO admin;

--
-- Name: TABLE action_type; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.action_type IS 'Ações possíveis que uma notícia pode sofrer';


--
-- Name: COLUMN action_type.name_action; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON COLUMN detectenv.action_type.name_action IS 'Exemplos: coleta, avaliação, em_checagem';


--
-- Name: action_type_id_action_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.action_type_id_action_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.action_type_id_action_seq OWNER TO admin;

--
-- Name: action_type_id_action_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.action_type_id_action_seq OWNED BY detectenv.action_type.id_action;


--
-- Name: checking_outcome; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.checking_outcome (
    id_checking_outcome integer NOT NULL,
    id_news integer NOT NULL,
    id_trusted_agency integer NOT NULL,
    datetime_outcome timestamp without time zone NOT NULL,
    datetime_sent_for_checking timestamp without time zone,
    is_fake boolean
);


ALTER TABLE detectenv.checking_outcome OWNER TO admin;

--
-- Name: TABLE checking_outcome; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.checking_outcome IS 'Dados de verificação de uma notícia em uma determinada agência de checagem';


--
-- Name: checking_outcome_id_checking_outcome_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.checking_outcome_id_checking_outcome_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.checking_outcome_id_checking_outcome_seq OWNER TO admin;

--
-- Name: checking_outcome_id_checking_outcome_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.checking_outcome_id_checking_outcome_seq OWNED BY detectenv.checking_outcome.id_checking_outcome;


--
-- Name: news; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.news (
    id_news integer NOT NULL,
    text_news character varying(500) NOT NULL,
    datetime_publication timestamp without time zone NOT NULL,
    classification_outcome boolean
);


ALTER TABLE detectenv.news OWNER TO admin;

--
-- Name: TABLE news; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.news IS 'Uma notícia que circula nas redes sociais';


--
-- Name: news_id_news_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.news_id_news_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.news_id_news_seq OWNER TO admin;

--
-- Name: news_id_news_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.news_id_news_seq OWNED BY detectenv.news.id_news;


--
-- Name: owner; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.owner (
    id_owner integer NOT NULL,
    name_owner character varying(100) NOT NULL,
    location character varying(45) NOT NULL
);


ALTER TABLE detectenv.owner OWNER TO admin;

--
-- Name: TABLE owner; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.owner IS 'Uma pessoa do mundo real';


--
-- Name: owner_id_owner_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.owner_id_owner_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.owner_id_owner_seq OWNER TO admin;

--
-- Name: owner_id_owner_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.owner_id_owner_seq OWNED BY detectenv.owner.id_owner;


--
-- Name: permission; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.permission (
    id_permission integer NOT NULL,
    id_permission_type integer NOT NULL,
    id_role integer NOT NULL
);


ALTER TABLE detectenv.permission OWNER TO admin;

--
-- Name: TABLE permission; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.permission IS 'Permissões no Painel Administrativo associadas a um perfil';


--
-- Name: permission_id_permission_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.permission_id_permission_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.permission_id_permission_seq OWNER TO admin;

--
-- Name: permission_id_permission_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.permission_id_permission_seq OWNED BY detectenv.permission.id_permission;


--
-- Name: permission_type; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.permission_type (
    id_permission_type integer NOT NULL,
    name_permission character varying(100) NOT NULL
);


ALTER TABLE detectenv.permission_type OWNER TO admin;

--
-- Name: TABLE permission_type; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.permission_type IS 'Tipos de permissões para o Painel Administrativo';


--
-- Name: permission_type_id_permission_type_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.permission_type_id_permission_type_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.permission_type_id_permission_type_seq OWNER TO admin;

--
-- Name: permission_type_id_permission_type_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.permission_type_id_permission_type_seq OWNED BY detectenv.permission_type.id_permission_type;


--
-- Name: post; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.post (
    id_post integer NOT NULL,
    id_social_media_account integer NOT NULL,
    id_news integer NOT NULL,
    parent_id_post integer,
    text_post character varying(500) NOT NULL,
    num_likes integer,
    num_shares integer,
    datetime_post timestamp without time zone NOT NULL
);


ALTER TABLE detectenv.post OWNER TO admin;

--
-- Name: TABLE post; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.post IS 'Postagem em uma rede social';


--
-- Name: COLUMN post.parent_id_post; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON COLUMN detectenv.post.parent_id_post IS 'Denota o compartilhamento de um post';


--
-- Name: COLUMN post.text_post; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON COLUMN detectenv.post.text_post IS 'Texto da postagem na rede social';


--
-- Name: COLUMN post.datetime_post; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON COLUMN detectenv.post.datetime_post IS 'Data e hora da postagem na rede social';


--
-- Name: post_id_post_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.post_id_post_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.post_id_post_seq OWNER TO admin;

--
-- Name: post_id_post_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.post_id_post_seq OWNED BY detectenv.post.id_post;


--
-- Name: role; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.role (
    id_role integer NOT NULL,
    name_role character varying(100) NOT NULL
);


ALTER TABLE detectenv.role OWNER TO admin;

--
-- Name: TABLE role; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.role IS 'Perfis de conta de usuário do Painel Administrativo';


--
-- Name: role_id_role_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.role_id_role_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.role_id_role_seq OWNER TO admin;

--
-- Name: role_id_role_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.role_id_role_seq OWNED BY detectenv.role.id_role;


--
-- Name: social_media; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.social_media (
    id_social_media integer NOT NULL,
    name_social_media character varying(100) NOT NULL
);


ALTER TABLE detectenv.social_media OWNER TO admin;

--
-- Name: social_media_account; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.social_media_account (
    id_social_media_account integer NOT NULL,
    id_social_media integer NOT NULL,
    id_owner integer NOT NULL,
    screen_name character varying(30) NOT NULL,
    date_creation date NOT NULL,
    blue_badge boolean DEFAULT false NOT NULL
);


ALTER TABLE detectenv.social_media_account OWNER TO admin;

--
-- Name: TABLE social_media_account; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.social_media_account IS 'Conta de uma pessoa em uma rede social';


--
-- Name: COLUMN social_media_account.screen_name; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON COLUMN detectenv.social_media_account.screen_name IS 'Nome exibido na rede social';


--
-- Name: COLUMN social_media_account.blue_badge; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON COLUMN detectenv.social_media_account.blue_badge IS 'Denota se é ou não uma CONTA VERIFICADA na rede social';


--
-- Name: social_media_account_id_social_media_account_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.social_media_account_id_social_media_account_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.social_media_account_id_social_media_account_seq OWNER TO admin;

--
-- Name: social_media_account_id_social_media_account_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.social_media_account_id_social_media_account_seq OWNED BY detectenv.social_media_account.id_social_media_account;


--
-- Name: social_media_id_social_media_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.social_media_id_social_media_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.social_media_id_social_media_seq OWNER TO admin;

--
-- Name: social_media_id_social_media_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.social_media_id_social_media_seq OWNED BY detectenv.social_media.id_social_media;


--
-- Name: trusted_agency; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.trusted_agency (
    id_trusted_agency integer NOT NULL,
    name_agency character varying(20) NOT NULL
);


ALTER TABLE detectenv.trusted_agency OWNER TO admin;

--
-- Name: TABLE trusted_agency; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.trusted_agency IS 'Agência de checagem de fatos';


--
-- Name: trusted_agency_id_trusted_agency_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.trusted_agency_id_trusted_agency_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.trusted_agency_id_trusted_agency_seq OWNER TO admin;

--
-- Name: trusted_agency_id_trusted_agency_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.trusted_agency_id_trusted_agency_seq OWNED BY detectenv.trusted_agency.id_trusted_agency;


--
-- Name: user_account; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.user_account (
    id_user_account integer NOT NULL,
    name_user_account character varying(100) NOT NULL,
    password character varying(100) NOT NULL
);


ALTER TABLE detectenv.user_account OWNER TO admin;

--
-- Name: TABLE user_account; Type: COMMENT; Schema: detectenv; Owner: admin
--

COMMENT ON TABLE detectenv.user_account IS 'Conta de usuário do Painel Administrativo';


--
-- Name: user_account_id_user_account_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.user_account_id_user_account_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.user_account_id_user_account_seq OWNER TO admin;

--
-- Name: user_account_id_user_account_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.user_account_id_user_account_seq OWNED BY detectenv.user_account.id_user_account;


--
-- Name: user_role; Type: TABLE; Schema: detectenv; Owner: admin
--

CREATE TABLE detectenv.user_role (
    id_user_role integer NOT NULL,
    id_user_account integer NOT NULL,
    id_role integer NOT NULL
);


ALTER TABLE detectenv.user_role OWNER TO admin;

--
-- Name: user_role_id_user_role_seq; Type: SEQUENCE; Schema: detectenv; Owner: admin
--

CREATE SEQUENCE detectenv.user_role_id_user_role_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detectenv.user_role_id_user_role_seq OWNER TO admin;

--
-- Name: user_role_id_user_role_seq; Type: SEQUENCE OWNED BY; Schema: detectenv; Owner: admin
--

ALTER SEQUENCE detectenv.user_role_id_user_role_seq OWNED BY detectenv.user_role.id_user_role;


--
-- Name: action_log id_action_log; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.action_log ALTER COLUMN id_action_log SET DEFAULT nextval('detectenv.action_log_id_action_log_seq'::regclass);


--
-- Name: action_type id_action; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.action_type ALTER COLUMN id_action SET DEFAULT nextval('detectenv.action_type_id_action_seq'::regclass);


--
-- Name: checking_outcome id_checking_outcome; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.checking_outcome ALTER COLUMN id_checking_outcome SET DEFAULT nextval('detectenv.checking_outcome_id_checking_outcome_seq'::regclass);


--
-- Name: news id_news; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.news ALTER COLUMN id_news SET DEFAULT nextval('detectenv.news_id_news_seq'::regclass);


--
-- Name: owner id_owner; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.owner ALTER COLUMN id_owner SET DEFAULT nextval('detectenv.owner_id_owner_seq'::regclass);


--
-- Name: permission id_permission; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.permission ALTER COLUMN id_permission SET DEFAULT nextval('detectenv.permission_id_permission_seq'::regclass);


--
-- Name: permission_type id_permission_type; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.permission_type ALTER COLUMN id_permission_type SET DEFAULT nextval('detectenv.permission_type_id_permission_type_seq'::regclass);


--
-- Name: post id_post; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.post ALTER COLUMN id_post SET DEFAULT nextval('detectenv.post_id_post_seq'::regclass);


--
-- Name: role id_role; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.role ALTER COLUMN id_role SET DEFAULT nextval('detectenv.role_id_role_seq'::regclass);


--
-- Name: social_media id_social_media; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.social_media ALTER COLUMN id_social_media SET DEFAULT nextval('detectenv.social_media_id_social_media_seq'::regclass);


--
-- Name: social_media_account id_social_media_account; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.social_media_account ALTER COLUMN id_social_media_account SET DEFAULT nextval('detectenv.social_media_account_id_social_media_account_seq'::regclass);


--
-- Name: trusted_agency id_trusted_agency; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.trusted_agency ALTER COLUMN id_trusted_agency SET DEFAULT nextval('detectenv.trusted_agency_id_trusted_agency_seq'::regclass);


--
-- Name: user_account id_user_account; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.user_account ALTER COLUMN id_user_account SET DEFAULT nextval('detectenv.user_account_id_user_account_seq'::regclass);


--
-- Name: user_role id_user_role; Type: DEFAULT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.user_role ALTER COLUMN id_user_role SET DEFAULT nextval('detectenv.user_role_id_user_role_seq'::regclass);


--
-- Data for Name: action_log; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.action_log (id_action_log, id_action, id_news, datetime_log, description_log) FROM stdin;
\.


--
-- Data for Name: action_type; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.action_type (id_action, name_action) FROM stdin;
\.


--
-- Data for Name: checking_outcome; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.checking_outcome (id_checking_outcome, id_news, id_trusted_agency, datetime_outcome, datetime_sent_for_checking, is_fake) FROM stdin;
\.


--
-- Data for Name: news; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.news (id_news, text_news, datetime_publication, classification_outcome) FROM stdin;
\.


--
-- Data for Name: owner; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.owner (id_owner, name_owner, location) FROM stdin;
\.


--
-- Data for Name: permission; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.permission (id_permission, id_permission_type, id_role) FROM stdin;
\.


--
-- Data for Name: permission_type; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.permission_type (id_permission_type, name_permission) FROM stdin;
\.


--
-- Data for Name: post; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.post (id_post, id_social_media_account, id_news, parent_id_post, text_post, num_likes, num_shares, datetime_post) FROM stdin;
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.role (id_role, name_role) FROM stdin;
\.


--
-- Data for Name: social_media; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.social_media (id_social_media, name_social_media) FROM stdin;
\.


--
-- Data for Name: social_media_account; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.social_media_account (id_social_media_account, id_social_media, id_owner, screen_name, date_creation, blue_badge) FROM stdin;
\.


--
-- Data for Name: trusted_agency; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.trusted_agency (id_trusted_agency, name_agency) FROM stdin;
\.


--
-- Data for Name: user_account; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.user_account (id_user_account, name_user_account, password) FROM stdin;
\.


--
-- Data for Name: user_role; Type: TABLE DATA; Schema: detectenv; Owner: admin
--

COPY detectenv.user_role (id_user_role, id_user_account, id_role) FROM stdin;
\.


--
-- Name: action_log_id_action_log_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.action_log_id_action_log_seq', 1, false);


--
-- Name: action_type_id_action_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.action_type_id_action_seq', 1, false);


--
-- Name: checking_outcome_id_checking_outcome_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.checking_outcome_id_checking_outcome_seq', 1, false);


--
-- Name: news_id_news_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.news_id_news_seq', 1, false);


--
-- Name: owner_id_owner_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.owner_id_owner_seq', 1, false);


--
-- Name: permission_id_permission_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.permission_id_permission_seq', 1, false);


--
-- Name: permission_type_id_permission_type_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.permission_type_id_permission_type_seq', 1, false);


--
-- Name: post_id_post_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.post_id_post_seq', 1, false);


--
-- Name: role_id_role_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.role_id_role_seq', 1, false);


--
-- Name: social_media_account_id_social_media_account_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.social_media_account_id_social_media_account_seq', 1, false);


--
-- Name: social_media_id_social_media_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.social_media_id_social_media_seq', 1, false);


--
-- Name: trusted_agency_id_trusted_agency_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.trusted_agency_id_trusted_agency_seq', 1, false);


--
-- Name: user_account_id_user_account_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.user_account_id_user_account_seq', 1, false);


--
-- Name: user_role_id_user_role_seq; Type: SEQUENCE SET; Schema: detectenv; Owner: admin
--

SELECT pg_catalog.setval('detectenv.user_role_id_user_role_seq', 1, false);


--
-- Name: action_log action_log_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.action_log
    ADD CONSTRAINT action_log_pkey PRIMARY KEY (id_action_log);


--
-- Name: action_type action_type_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.action_type
    ADD CONSTRAINT action_type_pkey PRIMARY KEY (id_action);


--
-- Name: checking_outcome checking_outcome_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.checking_outcome
    ADD CONSTRAINT checking_outcome_pkey PRIMARY KEY (id_checking_outcome);


--
-- Name: news news_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.news
    ADD CONSTRAINT news_pkey PRIMARY KEY (id_news);


--
-- Name: owner owner_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.owner
    ADD CONSTRAINT owner_pkey PRIMARY KEY (id_owner);


--
-- Name: permission permission_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.permission
    ADD CONSTRAINT permission_pkey PRIMARY KEY (id_permission);


--
-- Name: permission_type permission_type_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.permission_type
    ADD CONSTRAINT permission_type_pkey PRIMARY KEY (id_permission_type);


--
-- Name: post post_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.post
    ADD CONSTRAINT post_pkey PRIMARY KEY (id_post);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id_role);


--
-- Name: social_media_account social_media_account_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.social_media_account
    ADD CONSTRAINT social_media_account_pkey PRIMARY KEY (id_social_media_account);


--
-- Name: social_media social_media_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.social_media
    ADD CONSTRAINT social_media_pkey PRIMARY KEY (id_social_media);


--
-- Name: trusted_agency trusted_agency_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.trusted_agency
    ADD CONSTRAINT trusted_agency_pkey PRIMARY KEY (id_trusted_agency);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (id_user_account);


--
-- Name: user_role user_role_pkey; Type: CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.user_role
    ADD CONSTRAINT user_role_pkey PRIMARY KEY (id_user_role);


--
-- Name: id_permission_id_role_permission_idx; Type: INDEX; Schema: detectenv; Owner: admin
--

CREATE UNIQUE INDEX id_permission_id_role_permission_idx ON detectenv.permission USING btree (id_permission_type, id_role);


--
-- Name: id_social_id_owner_social_media_account_idx; Type: INDEX; Schema: detectenv; Owner: admin
--

CREATE UNIQUE INDEX id_social_id_owner_social_media_account_idx ON detectenv.social_media_account USING btree (id_social_media, id_owner);


--
-- Name: id_user_id_role_user_role_idx; Type: INDEX; Schema: detectenv; Owner: admin
--

CREATE UNIQUE INDEX id_user_id_role_user_role_idx ON detectenv.user_role USING btree (id_user_account, id_role);


--
-- Name: name_action_type_idx; Type: INDEX; Schema: detectenv; Owner: admin
--

CREATE UNIQUE INDEX name_action_type_idx ON detectenv.action_type USING btree (name_action);


--
-- Name: name_owner_idx; Type: INDEX; Schema: detectenv; Owner: admin
--

CREATE UNIQUE INDEX name_owner_idx ON detectenv.owner USING btree (name_owner);


--
-- Name: name_permission_type_idx; Type: INDEX; Schema: detectenv; Owner: admin
--

CREATE UNIQUE INDEX name_permission_type_idx ON detectenv.permission_type USING btree (name_permission);


--
-- Name: name_role_idx; Type: INDEX; Schema: detectenv; Owner: admin
--

CREATE UNIQUE INDEX name_role_idx ON detectenv.role USING btree (name_role);


--
-- Name: name_social_media_idx; Type: INDEX; Schema: detectenv; Owner: admin
--

CREATE UNIQUE INDEX name_social_media_idx ON detectenv.social_media USING btree (name_social_media);


--
-- Name: name_trusted_agency_idx; Type: INDEX; Schema: detectenv; Owner: admin
--

CREATE UNIQUE INDEX name_trusted_agency_idx ON detectenv.trusted_agency USING btree (name_agency);


--
-- Name: name_user_account_idx; Type: INDEX; Schema: detectenv; Owner: admin
--

CREATE UNIQUE INDEX name_user_account_idx ON detectenv.user_account USING btree (name_user_account);


--
-- Name: action_log action_type_action_log_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.action_log
    ADD CONSTRAINT action_type_action_log_fk FOREIGN KEY (id_action) REFERENCES detectenv.action_type(id_action);


--
-- Name: action_log news_action_log_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.action_log
    ADD CONSTRAINT news_action_log_fk FOREIGN KEY (id_news) REFERENCES detectenv.news(id_news);


--
-- Name: checking_outcome news_checking_outcome_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.checking_outcome
    ADD CONSTRAINT news_checking_outcome_fk FOREIGN KEY (id_news) REFERENCES detectenv.news(id_news);


--
-- Name: post news_post_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.post
    ADD CONSTRAINT news_post_fk FOREIGN KEY (id_news) REFERENCES detectenv.news(id_news);


--
-- Name: social_media_account owner_social_media_account_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.social_media_account
    ADD CONSTRAINT owner_social_media_account_fk FOREIGN KEY (id_owner) REFERENCES detectenv.owner(id_owner);


--
-- Name: permission permission_type_permission_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.permission
    ADD CONSTRAINT permission_type_permission_fk FOREIGN KEY (id_permission_type) REFERENCES detectenv.permission_type(id_permission_type);


--
-- Name: post post_post_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.post
    ADD CONSTRAINT post_post_fk FOREIGN KEY (parent_id_post) REFERENCES detectenv.post(id_post);


--
-- Name: permission role_permission_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.permission
    ADD CONSTRAINT role_permission_fk FOREIGN KEY (id_role) REFERENCES detectenv.role(id_role);


--
-- Name: user_role role_user_role_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.user_role
    ADD CONSTRAINT role_user_role_fk FOREIGN KEY (id_role) REFERENCES detectenv.role(id_role);


--
-- Name: post social_media_account_post_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.post
    ADD CONSTRAINT social_media_account_post_fk FOREIGN KEY (id_social_media_account) REFERENCES detectenv.social_media_account(id_social_media_account);


--
-- Name: social_media_account social_media_social_media_account_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.social_media_account
    ADD CONSTRAINT social_media_social_media_account_fk FOREIGN KEY (id_social_media) REFERENCES detectenv.social_media(id_social_media);


--
-- Name: checking_outcome trusted_agency_checking_outcome_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.checking_outcome
    ADD CONSTRAINT trusted_agency_checking_outcome_fk FOREIGN KEY (id_trusted_agency) REFERENCES detectenv.trusted_agency(id_trusted_agency);


--
-- Name: user_role user_account_user_role_fk; Type: FK CONSTRAINT; Schema: detectenv; Owner: admin
--

ALTER TABLE ONLY detectenv.user_role
    ADD CONSTRAINT user_account_user_role_fk FOREIGN KEY (id_user_account) REFERENCES detectenv.user_account(id_user_account);


--
-- PostgreSQL database dump complete
--

